# LocalGo MVP

Android-first Flutter MVP for local food, grocery, and parcel delivery. Includes a customer storefront/cart, demo checkout (COD and online-payment placeholder), order tracking, vendor workspace, delivery workspace, and admin overview.

## What works in this demo
- Browse/search products and filter by Food, Groceries, and Parcels.
- Add/remove items and calculate a cart subtotal in INR.
- Place demo orders using cash on delivery or a clearly marked online-payment placeholder.
- Track order status and advance statuses from the Vendor/Delivery workspace.
- Switch between Vendor, Delivery, and Admin demo dashboards.
- Runs entirely with in-memory sample data; app restart resets demo changes.

## What is not production-ready yet
- No real login, user accounts, authorization, or persistent database.
- Online payments are NOT charged; payment selection only creates a demo order.
- No real geolocation, maps, route calculation, push notifications, or live driver tracking.
- Role switching is for preview only and is not secure access control.
- Product/shop data and admin metrics are illustrative seed data.

## Run locally
1. Install Flutter stable and Android Studio, including Android SDK and an emulator or USB-debugging-enabled Android device.
2. In this folder, run:
   ```sh
   flutter pub get
   flutter run
   ```
3. To create a release APK:
   ```sh
   flutter build apk --release
   ```
   APK output: `build/app/outputs/flutter-apk/app-release.apk`.

If Android platform scaffolding is missing, run `flutter create . --platforms android` from this directory first, then `flutter pub get` and `flutter run`.

## Suggested production architecture
- Flutter Android app (this project is the UI/prototype).
- Supabase Auth + Postgres + Realtime + Storage, or a comparable backend.
- Server-side Edge Functions/API for payment verification, order assignment, fees, and privileged admin actions.
- Razorpay or another supported payment gateway for India. Never trust client-side payment success; verify signatures/webhooks server-side.
- Google Maps Platform (Maps SDK, Places, Routes) or another mapping provider for address selection and routing.
- Firebase Cloud Messaging for push notifications.

## Credentials and integrations needed
1. **Supabase**: project URL and anon/public key in the app; SQL migration below. Use server-side secrets only in Edge Functions. Do not put service-role keys in the mobile app.
2. **Payment gateway**: merchant account, test/live key ID, server-side secret, webhook secret, and backend endpoint. Start in sandbox mode. COD can work without payment credentials.
3. **Maps**: Google Maps API key with Android package/SHA restrictions and billing enabled, or chosen provider credentials.
4. **Push notifications**: Firebase project, Android app registration, `google-services.json`, FCM setup, and server credentials for sending notifications.
5. **Release**: Android application ID, signing keystore kept private, privacy policy, terms, refund/cancellation policy, and Play Console account.

## Backend schema starter
See `supabase/schema.sql`. Before launch, add RLS policies for each role, verified auth, audit logs, rate limits, order state transition validation, payment webhooks, and privacy/data retention rules. Never rely on a role string supplied by the client.

## Build the APK using only your Android phone (GitHub Actions)

This repository includes `.github/workflows/build-apk.yml` to build an installable **debug APK** on GitHub's hosted runner. This environment did not compile or test an APK itself.

1. On your phone, sign in to GitHub and create a **private** repository (for example `localgo-app`).
2. Upload the contents of this project to the repository's root. Ensure `pubspec.yaml`, `lib/`, `supabase/`, and `.github/workflows/build-apk.yml` are at the repository root (not nested inside another `localgo_mvp` folder).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build LocalGo Android APK**, tap **Run workflow**, then open the newest run.
5. Wait for the workflow to finish successfully. Under **Artifacts**, download `LocalGo-Android-APK` and extract it. The file is `app-debug.apk`.
6. Tap the APK on your Android phone to install. Android may ask you to allow installs from your browser or file manager; only enable this for the app you used to download the file.

The APK is a demo build. Orders are stored in memory and reset when the app restarts. Online payment is a placeholder and does not charge money. Do not use it for real customer transactions until authentication, backend authorization, persistent storage, and server-verified payments are added.
