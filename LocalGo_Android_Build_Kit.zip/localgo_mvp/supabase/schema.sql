-- LocalGo starter schema for Supabase Postgres. Review and harden policies before production.
create extension if not exists pgcrypto;

create type public.app_role as enum ('customer', 'vendor', 'delivery', 'admin');
create type public.order_status as enum ('placed', 'accepted', 'preparing', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'cancelled');
create type public.payment_method as enum ('cod', 'online');
create type public.payment_status as enum ('pending', 'authorized', 'paid', 'failed', 'refunded', 'cash_due', 'cash_collected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now()
);

create table public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  name text not null,
  category text not null check (category in ('food','groceries','parcels','other')),
  description text,
  phone text,
  address text not null,
  latitude double precision,
  longitude double precision,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  description text,
  price_paise integer not null check (price_paise >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  image_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.delivery_addresses (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id) on delete cascade,
  label text,
  address text not null,
  latitude double precision,
  longitude double precision,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  public_code text unique not null default ('LG-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))),
  customer_id uuid not null references public.profiles(id),
  shop_id uuid not null references public.shops(id),
  delivery_partner_id uuid references public.profiles(id),
  address_id uuid references public.delivery_addresses(id),
  delivery_address_snapshot text not null,
  status public.order_status not null default 'placed',
  payment_method public.payment_method not null,
  payment_status public.payment_status not null default 'pending',
  subtotal_paise integer not null check (subtotal_paise >= 0),
  delivery_fee_paise integer not null default 0 check (delivery_fee_paise >= 0),
  platform_fee_paise integer not null default 0 check (platform_fee_paise >= 0),
  total_paise integer not null check (total_paise >= 0),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name_snapshot text not null,
  unit_price_paise integer not null check (unit_price_paise >= 0),
  quantity integer not null check (quantity > 0),
  line_total_paise integer not null check (line_total_paise >= 0)
);

create table public.order_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  actor_id uuid references public.profiles(id),
  status public.order_status not null,
  note text,
  created_at timestamptz not null default now()
);

create table public.payment_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  provider text not null,
  provider_payment_id text,
  event_type text not null,
  verified boolean not null default false,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index orders_customer_created_idx on public.orders(customer_id, created_at desc);
create index orders_vendor_status_idx on public.orders(shop_id, status, created_at desc);
create index orders_delivery_status_idx on public.orders(delivery_partner_id, status, created_at desc);
create index products_shop_available_idx on public.products(shop_id, is_available);

-- Enable RLS; add narrowly scoped policies before connecting a client.
alter table public.profiles enable row level security;
alter table public.shops enable row level security;
alter table public.products enable row level security;
alter table public.delivery_addresses enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_events enable row level security;
alter table public.payment_events enable row level security;

-- Deliberately no permissive client policies are included. Define policies after deciding
-- whether vendors can manage only their shops, delivery partners only assigned orders,
-- and admins are verified server-side. Do not ship with RLS enabled but untested.
