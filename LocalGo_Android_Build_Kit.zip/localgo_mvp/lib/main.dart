import 'package:flutter/material.dart';

void main() => runApp(const LocalGoApp());

const brand = Color(0xFF16845B);

class LocalGoApp extends StatelessWidget {
  const LocalGoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'LocalGo', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: brand), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF7F9F8)),
    home: const HomeShell(),
  );
}

class Product {
  Product(this.name, this.shop, this.category, this.price, this.emoji, {this.description = ''});
  final String name, shop, category, emoji, description;
  final int price;
}

final products = <Product>[
  Product('Fresh Vegetable Basket', 'Green Basket Market', 'Groceries', 180, '🥬', description: 'Seasonal vegetables for everyday cooking'),
  Product('Farm Fresh Eggs (12)', 'Green Basket Market', 'Groceries', 95, '🥚'),
  Product('Masala Dosa', 'Udupi Corner', 'Food', 110, '🥞', description: 'Crispy dosa with chutney and sambar'),
  Product('Veg Biryani', 'Spice Route Kitchen', 'Food', 160, '🍛'),
  Product('Parcel Pickup', 'LocalGo Courier', 'Parcels', 79, '📦', description: 'Local pickup and drop-off, starting price'),
  Product('Milk 1 Litre', 'Green Basket Market', 'Groceries', 34, '🥛'),
];

class OrderItem { OrderItem(this.product, this.qty); final Product product; int qty; }
class LocalOrder {
  LocalOrder({required this.id, required this.items, required this.total, required this.payment, this.status = 'Order placed', this.customer = 'Demo Customer'});
  final String id, payment, customer; final List<OrderItem> items; final int total; String status;
  String get summary => items.map((e) => '${e.qty}× ${e.product.name}').join(', ');
}

class AppState extends ChangeNotifier {
  static final AppState instance = AppState._();
  AppState._();
  final Map<Product, int> cart = {};
  final List<LocalOrder> orders = [
    LocalOrder(id: 'LG-1042', items: [OrderItem(products[2], 1), OrderItem(products[5], 2)], total: 178, payment: 'Cash on delivery', status: 'Out for delivery'),
  ];
  String role = 'Customer';
  void add(Product p) { cart[p] = (cart[p] ?? 0) + 1; notifyListeners(); }
  void remove(Product p) { if (cart.containsKey(p)) { if (cart[p] == 1) { cart.remove(p); } else { cart[p] = cart[p]! - 1; } notifyListeners(); } }
  int get total => cart.entries.fold(0, (s, e) => s + e.key.price * e.value);
  int get count => cart.values.fold(0, (s, e) => s + e);
  void checkout(String payment) {
    if (cart.isEmpty) return;
    orders.insert(0, LocalOrder(id: 'LG-${1043 + orders.length}', items: cart.entries.map((e) => OrderItem(e.key, e.value)).toList(), total: total, payment: payment));
    cart.clear(); notifyListeners();
  }
  void advance(LocalOrder o) {
    const statuses = ['Order placed', 'Accepted by shop', 'Preparing', 'Ready for pickup', 'Picked up', 'Out for delivery', 'Delivered'];
    final i = statuses.indexOf(o.status); if (i >= 0 && i < statuses.length - 1) o.status = statuses[i + 1]; notifyListeners();
  }
}

class HomeShell extends StatefulWidget { const HomeShell({super.key}); @override State<HomeShell> createState() => _HomeShellState(); }
class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  final state = AppState.instance;
  @override void initState() { super.initState(); state.addListener(_refresh); }
  @override void dispose() { state.removeListener(_refresh); super.dispose(); }
  void _refresh() { if (mounted) setState(() {}); }
  @override Widget build(BuildContext context) {
    final pages = [CustomerPage(onCart: () => setState(() => tab = 1)), CartPage(), OrdersPage(), RolePage()];
    return Scaffold(
      appBar: AppBar(title: Row(children: [Container(padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.local_shipping, color: Colors.white)), const SizedBox(width: 10), const Text('LocalGo', style: TextStyle(fontWeight: FontWeight.w800)), const Spacer(), const Text('DEMO', style: TextStyle(fontSize: 10, letterSpacing: 1.2, color: brand, fontWeight: FontWeight.bold))]),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: [const NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Explore'), NavigationDestination(icon: Badge(isLabelVisible: state.count > 0, label: Text('${state.count}'), child: const Icon(Icons.shopping_bag_outlined)), label: 'Cart'), const NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Orders'), const NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Workspaces')]),
    );
  }
}

class CustomerPage extends StatefulWidget { const CustomerPage({super.key, required this.onCart}); final VoidCallback onCart; @override State<CustomerPage> createState() => _CustomerPageState(); }
class _CustomerPageState extends State<CustomerPage> {
  String category = 'All'; String search = '';
  @override Widget build(BuildContext context) {
    final visible = products.where((p) => (category == 'All' || p.category == category) && ('${p.name} ${p.shop}'.toLowerCase().contains(search.toLowerCase()))).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF116747), Color(0xFF27A875)]), borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Your neighbourhood, delivered.', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)), SizedBox(height: 6), Text('Food • Groceries • Parcels', style: TextStyle(color: Colors.white70)), SizedBox(height: 14), Row(children: [Icon(Icons.location_on_outlined, color: Colors.white, size: 18), SizedBox(width: 5), Text('Set delivery address', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))])]),
      const SizedBox(height: 16), TextField(decoration: InputDecoration(hintText: 'Search shops or products', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none)), onChanged: (v) => setState(() => search = v)),
      const SizedBox(height: 14), SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: ['All', 'Food', 'Groceries', 'Parcels'].map((c) => Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c))).toList())),
      const SizedBox(height: 18), Row(children: [const Text('Popular nearby', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const Spacer(), Text('${visible.length} items', style: const TextStyle(color: Colors.grey))]), const SizedBox(height: 8),
      ...visible.map((p) => Card(color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFFE7ECE9))), child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [Container(width: 62, height: 62, alignment: Alignment.center, decoration: BoxDecoration(color: const Color(0xFFEFF7F2), borderRadius: BorderRadius.circular(14)), child: Text(p.emoji, style: const TextStyle(fontSize: 30))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(p.shop, style: const TextStyle(color: Colors.grey, fontSize: 12)), const SizedBox(height: 5), Text('₹${p.price}', style: const TextStyle(color: brand, fontWeight: FontWeight.w800))])), FilledButton.tonal(onPressed: () { AppState.instance.add(p); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${p.name} added to cart'), duration: const Duration(milliseconds: 900))); }, child: const Text('Add'))]))),
      const SizedBox(height: 70),
    ]);
  }
}

class CartPage extends StatefulWidget { const CartPage({super.key}); @override State<CartPage> createState() => _CartPageState(); }
class _CartPageState extends State<CartPage> { String payment = 'Cash on delivery';
  @override Widget build(BuildContext context) { final s = AppState.instance; return ListView(padding: const EdgeInsets.all(16), children: [const Text('Your cart', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 12), if (s.cart.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 55), child: Column(children: [Icon(Icons.shopping_bag_outlined, size: 60, color: Colors.grey), SizedBox(height: 12), Text('Your cart is empty'), Text('Explore local shops to add items.', style: TextStyle(color: Colors.grey))])) else ...s.cart.entries.map((e) => ListTile(contentPadding: EdgeInsets.zero, leading: Text(e.key.emoji, style: const TextStyle(fontSize: 28)), title: Text(e.key.name), subtitle: Text('₹${e.key.price} each'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => s.remove(e.key), icon: const Icon(Icons.remove_circle_outline)), Text('${e.value}'), IconButton(onPressed: () => s.add(e.key), icon: const Icon(Icons.add_circle_outline))]))), if (s.cart.isNotEmpty) ...[const Divider(height: 28), Row(children: [const Text('Subtotal', style: TextStyle(fontSize: 16)), const Spacer(), Text('₹${s.total}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))]), const SizedBox(height: 20), const Text('Payment method', style: TextStyle(fontWeight: FontWeight.bold)), RadioListTile<String>(contentPadding: EdgeInsets.zero, value: 'Cash on delivery', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: const Text('Cash on delivery'), secondary: const Icon(Icons.payments_outlined)), RadioListTile<String>(contentPadding: EdgeInsets.zero, value: 'Online payment (demo)', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: const Text('Pay online'), subtitle: const Text('Payment gateway setup required'), secondary: const Icon(Icons.credit_card)), const SizedBox(height: 12), FilledButton.icon(onPressed: () { final method = payment == 'Cash on delivery' ? payment : 'Online payment (demo — not charged)'; s.checkout(method); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo order placed successfully'))); }, icon: const Icon(Icons.check_circle_outline), label: const Padding(padding: EdgeInsets.all(14), child: Text('Place order')))], const SizedBox(height: 50)]); }
}

class OrdersPage extends StatelessWidget { const OrdersPage({super.key}); @override Widget build(BuildContext context) { final s = AppState.instance; return AnimatedBuilder(animation: s, builder: (_, __) => ListView(padding: const EdgeInsets.all(16), children: [const Text('Orders & tracking', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('Demo order status updates; connect realtime backend for live tracking.', style: TextStyle(color: Colors.grey)), const SizedBox(height: 12), if (s.orders.isEmpty) const Text('No orders yet.') else ...s.orders.map((o) => Card(color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFFE5EAE7))), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Text(o.id, style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('₹${o.total}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))]), const SizedBox(height: 7), Text(o.summary), const SizedBox(height: 12), Row(children: [const Icon(Icons.route, color: brand), const SizedBox(width: 7), Expanded(child: Text(o.status, style: const TextStyle(color: brand, fontWeight: FontWeight.bold)))]), const SizedBox(height: 8), ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: (['Order placed','Accepted by shop','Preparing','Ready for pickup','Picked up','Out for delivery','Delivered'].indexOf(o.status) + 1) / 7, minHeight: 6)), const SizedBox(height: 9), Text(o.payment, style: const TextStyle(color: Colors.grey, fontSize: 12))])))]))); } }

class RolePage extends StatefulWidget { const RolePage({super.key}); @override State<RolePage> createState() => _RolePageState(); }
class _RolePageState extends State<RolePage> { String role = 'Vendor';
  @override Widget build(BuildContext context) { final s = AppState.instance; return ListView(padding: const EdgeInsets.all(16), children: [const Text('Workspaces', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('Switch roles to preview the MVP dashboards.', style: TextStyle(color: Colors.grey)), const SizedBox(height: 14), Wrap(spacing: 8, children: ['Vendor', 'Delivery', 'Admin'].map((r) => ChoiceChip(label: Text(r), selected: role == r, onSelected: (_) => setState(() => role = r)).toList()), const SizedBox(height: 18), if (role == 'Vendor') _vendor(s) else if (role == 'Delivery') _delivery(s) else _admin(s)]); }
  Widget _vendor(AppState s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const _MetricRow(title: 'Incoming orders', value: '2', icon: Icons.notifications_active_outlined), const SizedBox(height: 8), const _MetricRow(title: 'Products listed', value: '6', icon: Icons.inventory_2_outlined), const SizedBox(height: 16), const Text('Order queue', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8), ...s.orders.map((o) => _OrderActionCard(order: o, actionLabel: 'Advance status', onTap: () => s.advance(o))), const SizedBox(height: 16), const Text('Catalog preview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), ...products.take(4).map((p) => ListTile(contentPadding: EdgeInsets.zero, leading: Text(p.emoji, style: const TextStyle(fontSize: 24)), title: Text(p.name), subtitle: Text(p.shop), trailing: Text('₹${p.price}')))]);
  Widget _delivery(AppState s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const _MetricRow(title: 'Assigned deliveries', value: '1', icon: Icons.delivery_dining), const SizedBox(height: 8), const _MetricRow(title: 'Completed today', value: '3', icon: Icons.task_alt), const SizedBox(height: 16), const Text('My delivery jobs', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8), ...s.orders.where((o) => o.status != 'Delivered').map((o) => _OrderActionCard(order: o, actionLabel: 'Update delivery status', onTap: () => s.advance(o))), const Card(child: ListTile(leading: Icon(Icons.map_outlined), title: Text('Live route navigation'), subtitle: Text('Requires Google Maps API key and location permission.')))]);
  Widget _admin(AppState s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const _MetricRow(title: 'Orders in system', value: '4', icon: Icons.receipt_long), const SizedBox(height: 8), const _MetricRow(title: 'Active vendors', value: '3', icon: Icons.storefront), const SizedBox(height: 8), const _MetricRow(title: 'Delivery partners', value: '5', icon: Icons.delivery_dining), const SizedBox(height: 16), const Text('Operations', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const Card(child: Column(children: [ListTile(leading: Icon(Icons.people_outline), title: Text('Customer and partner accounts'), subtitle: Text('Demo view — role-based access not enabled')), Divider(height: 1), ListTile(leading: Icon(Icons.payments_outlined), title: Text('Fees & commissions'), subtitle: Text('Configure in backend before launch')), Divider(height: 1), ListTile(leading: Icon(Icons.support_agent), title: Text('Disputes and support'), subtitle: Text('Admin workflow placeholder'))])), const SizedBox(height: 12), const Text('Recent orders', style: TextStyle(fontWeight: FontWeight.bold)), ...s.orders.map((o) => ListTile(title: Text(o.id), subtitle: Text(o.status), trailing: Text('₹${o.total}')))]);
}

class _MetricRow extends StatelessWidget { const _MetricRow({required this.title, required this.value, required this.icon}); final String title, value; final IconData icon; @override Widget build(BuildContext context) => Card(color: Colors.white, elevation: 0, child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFEAF5EF), child: Icon(icon, color: brand)), title: Text(title), trailing: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)))); }
class _OrderActionCard extends StatelessWidget { const _OrderActionCard({required this.order, required this.actionLabel, required this.onTap}); final LocalOrder order; final String actionLabel; final VoidCallback onTap; @override Widget build(BuildContext context) => Card(color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 9), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Text(order.id, style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('₹${order.total}', style: const TextStyle(fontWeight: FontWeight.bold))]), const SizedBox(height: 4), Text(order.summary, maxLines: 2, overflow: TextOverflow.ellipsis), const SizedBox(height: 6), Text(order.status, style: const TextStyle(color: brand)), const SizedBox(height: 8), Align(alignment: Alignment.centerRight, child: OutlinedButton(onPressed: order.status == 'Delivered' ? null : onTap, child: Text(order.status == 'Delivered' ? 'Completed' : actionLabel)))]))); }
